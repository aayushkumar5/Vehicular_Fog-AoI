"""
VFC Simulation Environment
Handles:
  • AoI computation — Equation (14)
  • Distance check / β_ij — Equation (1)
  • Accept / Reject decision (AoI ≤ threshold)
  • State vector construction
  • Reward computation — Equation (20)
"""

import math
import numpy as np
from dataclasses import dataclass, field
from typing import Optional

# ── Constants ─────────────────────────────────────────────────────
D_MAX         = 115.0   # max RSU coverage distance (pixels/units)
ERROR_RATE    = 0.10    # ε — packet error rate
MAX_N         = 15      # max vehicles for fixed state vector size
NUM_RSUS      = 3


@dataclass
class VehicleInput:
    """Raw vehicle data received from frontend."""
    id:     str
    x:      float
    y:      float
    speed:  float
    direction: int       # +1 or -1
    lane:   str          # "A" or "B"
    lambda_rate: float   # packet arrival rate λ
    mu_v:   float        # vehicle computing capacity


@dataclass
class RSUConfig:
    """RSU configuration from frontend."""
    id:   str
    x:    float
    y:    float         # always DIVIDER_Y on frontend
    mu_r: float         # RSU computing capacity


@dataclass
class VehicleResult:
    """Per-vehicle result sent back to frontend."""
    id:           str
    aoi:          float
    beta:         int            # 0 or 1 — Eq.(1)
    assigned_rsu: Optional[str]
    distance:     float
    status:       str            # "ACCEPTED" | "REJECTED" | "OUT_OF_RANGE"
    reason:       str
    action:       int            # 0 or 1
    q_value:      float
    v_value:      float
    phase:        str            # for frontend phase system


def euclidean(x1, y1, x2, y2) -> float:
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


def calc_aoi(lambda_rate: float, mu_r: float, eps: float = ERROR_RATE) -> float:
    """
    AoI formula — Equation (14):
    Δᵢ,ₕ = 1/((1-ε)λ) + 1/((1-ε)μᵣ) + λμᵣε/(μᵣ(λ+μᵣ))
    """
    if lambda_rate <= 0 or mu_r <= 0:
        return 0.28
    t1 = 1.0 / ((1 - eps) * lambda_rate)
    t2 = 1.0 / ((1 - eps) * mu_r)
    t3 = (lambda_rate * mu_r * eps) / (lambda_rate + mu_r)
    return min(t1 + t2 + t3, 0.28)


def find_best_rsu(vx: float, vy: float, rsus: list[RSUConfig]) -> tuple[Optional[RSUConfig], float]:
    """Equation (1): Find closest RSU within D_MAX."""
    best_rsu, min_d = None, float("inf")
    for rsu in rsus:
        d = euclidean(vx, vy, rsu.x, rsu.y)
        if d <= D_MAX and d < min_d:
            min_d = d
            best_rsu = rsu
    return best_rsu, min_d if best_rsu else float("inf")


def build_state_vector(
    vehicles: list[VehicleInput],
    rsus:     list[RSUConfig],
    aoi_map:  dict[str, float],
    n:        int = MAX_N,
) -> np.ndarray:
    """
    State vector — sₜ = [λ(N), μ_r(M), μ_v(N), Δ(N)]
    Padded/truncated to fixed size n.
    """
    # Pad to n vehicles
    lambdas  = [v.lambda_rate / 10.0  for v in vehicles[:n]]
    mu_vs    = [v.mu_v / 10.0         for v in vehicles[:n]]
    deltas   = [aoi_map.get(v.id, 0.28) / 0.28 for v in vehicles[:n]]
    mu_rs    = [r.mu_r / 12.0         for r in rsus]

    while len(lambdas) < n: lambdas.append(0.0)
    while len(mu_vs)   < n: mu_vs.append(0.0)
    while len(deltas)  < n: deltas.append(1.0)

    return np.array(lambdas + mu_rs + mu_vs + deltas, dtype=np.float32)


def compute_reward(vehicle_results: list[VehicleResult]) -> float:
    """Reward — Equation (20): rₜ = 1/Δₜ (average AoI inverse)."""
    if not vehicle_results:
        return 0.0
    avg_aoi = sum(r.aoi for r in vehicle_results) / len(vehicle_results)
    return 1.0 / (avg_aoi + 1e-6)


def process_vehicles(
    vehicles:      list[VehicleInput],
    rsus:          list[RSUConfig],
    aoi_threshold: float,
    actions:       list[int],
    q_values:      list[float],
    v_value:       float,
) -> list[VehicleResult]:
    """
    Core fog formation logic:
    1. Compute distance → β_ij — Eq.(1)
    2. Compute AoI — Eq.(14)
    3. Check AoI ≤ threshold — Eq.(19a)
    4. Apply DDQN action
    5. Return ACCEPTED / REJECTED / OUT_OF_RANGE per vehicle
    """
    results = []

    for i, v in enumerate(vehicles):
        best_rsu, distance = find_best_rsu(v.x, v.y, rsus)
        action  = actions[i] if i < len(actions) else 0
        q_value = q_values[i] if i < len(q_values) else 0.0

        # ── Out of range ──────────────────────────────────────────
        if best_rsu is None:
            results.append(VehicleResult(
                id=v.id, aoi=0.28, beta=0,
                assigned_rsu=None, distance=distance,
                status="OUT_OF_RANGE",
                reason=f"d={distance:.1f} > d_max={D_MAX}",
                action=0, q_value=q_value, v_value=v_value,
                phase="OUT",
            ))
            continue

        # ── Compute AoI — Eq.(14) ─────────────────────────────────
        aoi = calc_aoi(v.lambda_rate, best_rsu.mu_r)

        # ── Accept / Reject logic ─────────────────────────────────
        # Constraint Eq.(19a): Δᵢ · βᵢⱼ ≤ Δᵗʰᵢ
        # Constraint Eq.(19b): λ ≤ μᵣ
        capacity_ok = v.lambda_rate <= best_rsu.mu_r
        aoi_ok      = aoi <= aoi_threshold

        if not aoi_ok:
            status = "REJECTED"
            reason = f"AoI {aoi:.4f}s > threshold {aoi_threshold}s — Eq.(19a)"
            action = 0   # override — cannot offload
            phase  = "CANDIDATE"
        elif not capacity_ok:
            status = "REJECTED"
            reason = f"λ={v.lambda_rate:.2f} > μᵣ={best_rsu.mu_r} — Eq.(19b)"
            action = 0
            phase  = "CANDIDATE"
        elif action == 1:
            status = "ACCEPTED"
            reason = f"AoI {aoi:.4f}s ≤ {aoi_threshold}s · Q={q_value:.3f}"
            phase  = "FOG"
        else:
            # Agent chose not to offload (ε-greedy exploration)
            status = "REJECTED"
            reason = f"Agent action=0 (ε-greedy) · AoI OK"
            phase  = "CANDIDATE"

        results.append(VehicleResult(
            id=v.id, aoi=aoi, beta=1,
            assigned_rsu=best_rsu.id, distance=distance,
            status=status, reason=reason,
            action=action, q_value=q_value, v_value=v_value,
            phase=phase,
        ))

    return results
